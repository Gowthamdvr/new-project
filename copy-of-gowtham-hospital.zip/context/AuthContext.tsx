import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Doctor, AuthState } from '../types';
import { db } from '../services/mockDatabase';

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<boolean>;
  register: (user: Omit<User, 'id' | 'role' | 'createdAt'>) => Promise<void>;
  logout: () => void;
  updateProfile: (user: User | Doctor) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children?: ReactNode }) => {
  const [auth, setAuth] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
  });

  useEffect(() => {
    // Check for persisted session (simple simulation)
    const storedUser = localStorage.getItem('session_user');
    if (storedUser) {
      setAuth({ user: JSON.parse(storedUser), isAuthenticated: true });
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    try {
        const user = await db.login(email, password);
        if (user) {
          localStorage.setItem('session_user', JSON.stringify(user));
          setAuth({ user, isAuthenticated: true });
          return true;
        }
    } catch (e) {
        console.error("Login failed", e);
    }
    return false;
  };

  const register = async (userData: Omit<User, 'id' | 'role' | 'createdAt'>) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
      role: 'user',
      createdAt: new Date().toISOString(),
    };
    await db.addUser(newUser);
    // Auto login
    localStorage.setItem('session_user', JSON.stringify(newUser));
    setAuth({ user: newUser, isAuthenticated: true });
  };

  const logout = () => {
    localStorage.removeItem('session_user');
    setAuth({ user: null, isAuthenticated: false });
  };

  const updateProfile = (updatedUser: User | Doctor) => {
    localStorage.setItem('session_user', JSON.stringify(updatedUser));
    setAuth(prev => ({ ...prev, user: updatedUser }));
  };

  return (
    <AuthContext.Provider value={{ ...auth, login, register, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
